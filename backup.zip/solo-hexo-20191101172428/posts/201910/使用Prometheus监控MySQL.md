title: 使用Prometheus监控MySQL
date: '2019-10-21 19:11:49'
updated: '2019-10-21 19:11:49'
tags: [Prometheus]
permalink: /articles/2019/10/21/1571656309793.html
---
![](https://img.hacpai.com/bing/20180106.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

之前我们讲了使用[Prometheus监控服务器](https://mp.weixin.qq.com/s?__biz=Mzg3NjE0ODM2NA==&mid=2247483773&idx=1&sn=1e5ec2b59af5ac46661fcda19c6e31dc&chksm=cf37e29ef8406b886e30cf31d1024ca0fd25ae15e5248da92c4093f40213c7f3732e799bfa8f&scene=0&xtrack=1&key=3d64c8ab0dfd206a2c47f16e4718cf782b274076750e6c42eab115f1f7dbeb7ea5a7bbd0a4f79f7c54cbdfea198c7afc486199c77c374029eba3f735df3e70b5f3d444a6629c590092efb6debd803cd5&ascene=1&uin=MTQ2MDEzMTM4MA%3D%3D&devicetype=Windows+10&version=62070152&lang=zh_CN&pass_ticket=NXhWiJ3Bp5MocTHkgjseb9i4xCNLedzr7Yi7DQoFCHfC9UgvCb56EBSwxmr2CA4O)状态，今天我们使用Prometheus监控下数据库。

## 安装配置
* 从[mysqld_exporter](https://github.com/prometheus/mysqld_exporter/releases/download/v0.12.1/mysqld_exporter-0.12.1.linux-amd64.tar.gz) 下载好mysql的exporter，上传至服务器。  

* 修改exporter配置
在root目录下建立文件 .my.cnf，输入mysql的访问参数

```
[client]
host = 192.168.249.129
user = root
password = 000000
```


使用如下shell命令进行安装并启动

```shell
tar zxvf mysqld_exporter-0.12.1.linux-amd64.tar.gz
mv node_exporter-0.18.1.linux-amd64 mysqld_exporter
nohup ./mysqld_exporter --web.listen-address=":9200" &
```  
启动完成后，用浏览器打开`http://192.168.249.129:9200/`进行访问,显示效果如下：

![image.png](https://img.hacpai.com/file/2019/10/image-f83c7ac3.png)


* 修改prometheus配置
在prometheus`scrape_configs`中加入mysql的监听地址

```
- job_name: 'mysql29'
    static_configs:
    - targets: ['192.168.249.129:9200']
```

## 监控报表
* 从grafana[官网](https://grafana.com/grafana/dashboards)上查找Mysql的监控dashboard `MySQL_Overview`并将其导入grafana。
![image.png](https://img.hacpai.com/file/2019/10/image-6e52b651.png)


* 查看监控效果
![image.png](https://img.hacpai.com/file/2019/10/image-b575362e.png)
![image.png](https://img.hacpai.com/file/2019/10/image-adbf4bb9.png)




