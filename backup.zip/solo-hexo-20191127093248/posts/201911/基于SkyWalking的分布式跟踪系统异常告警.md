title: 基于SkyWalking的分布式跟踪系统 - 异常告警
date: '2019-11-26 08:53:06'
updated: '2019-11-26 08:53:06'
tags: [运维监控, 微服务, Skywalking]
permalink: /articles/2019/11/26/1574729586468.html
---
![](https://img.hacpai.com/bing/20180719.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

通过前面2篇文章我们搭建了SW的基础环境，监控了微服务，能了解所有服务的运行情况。但是当出现服务响应慢，接口耗时严重时我们需要立即定位到问题，这就需要我们今天的主角--监控告警，同时此篇也是SW系列的最后一篇。

## UI参数
首先我们认识一下SW DashBoard上的几个关键参数，如下图所示
![image.png](https://img.hacpai.com/file/2019/11/image-5b42c135.png)




## 告警配置

### 告警流程
skywalking发送告警的基本原理是每隔一段时间轮询skywalking-collector收集到的链路追踪的数据，再根据所配置的告警规则（如服务响应时间、服务响应时间百分比）等，如果达到阈值则发送响应的告警信息。发送告警信息是以线程池异步的方式调用webhook接口完成，（具体的webhook接口可以使用者自行定义），从而开发者可以在指定的webhook接口中自行编写各种告警方式，钉钉告警、邮件告警等等。

### 规则配置

告警的核心由一组规则驱动，这些规则定义在 `config/alarm-settings.yml`，打开之后如下所示：
![image.png](https://img.hacpai.com/file/2019/11/image-74469642.png)


告警规则的定义分为两部分。
* 告警规则。它们定义了应该如何触发度量警报，应该考虑什么条件。
* [网络钩子](#Webhook}。当警告触发时，哪些服务终端需要被告知。

告警规则主要有以下几点

* **Rule name。** 在告警信息中显示的唯一名称。必须以_rule结尾。
* **Metrics name。**  也是oal脚本中的度量名。
* **Include names。** 其下的实体名称都在此规则中。比如服务名，终端名。
* **Threshold。** 阈值。
* **OP。**  操作符, 支持 >, <, =。
* **Period.。**  多久检查一次当前的指标数据是否符合告警规则这是一个时间窗口，与后端部署环境时间相匹配。
* **Count。**  在一个Period窗口中，如果values超过Threshold值（按op），达到Count值，需要发送警报。
* **Silence period。** 在时间N中触发报警后，在TN -> TN + period这个阶段不告警。 默认情况下，它和Period一样，这意味着相同的告警（在同一个Metrics name拥有相同的Id）在同一个Period内只会触发一次

### Webhook

SkyWalking 的告警 Webhook 要求对等方是一个 Web 容器. 告警的消息会通过 HTTP 请求进行发送, 请求方法为 POST, Content-Type 为 application/json, JSON 格式基于 List<org.apache.skywalking.oap.server.core.alarm.AlarmMessage, 包含以下信息.

* scopeId. 所有可用的 Scope 请查阅 `org.apache.skywalking.oap.server.core.source.DefaultScopeDefine`.
* name. 目标 Scope 的实体名称.
* id0. Scope 实体的 ID.
* id1. 未使用.alarmMessage. 报警消息内容.
* startTime. 告警时间, 位于当前时间与 UTC 1920/1/1 之间.
```json
[{
	"scopeId": 1, 
        "name": "serviceA", 
	"id0": 12,  
	"id1": 0,  
	"alarmMessage": "alarmMessage xxxx",
	"startTime": 1560524171000
}, {
	"scopeId": 1,
        "name": "serviceB",
	"id0": 23,
	"id1": 0,
	"alarmMessage": "alarmMessage yyy",
	"startTime": 1560524171000
}]
```


## 代码实战
* 编写实体类用于接收sw告警消息
```java
@Data
public class SwAlarmVO {
    private int scopeId;
    private String name;
    private int id0;
    private int id1;
    private String alarmMessage;
    private long startTime;
}
```

* 编写webhook接口
```
@RestController
@RequestMapping("sw")
@Log4j2
public class AlarmController {
    @PostMapping("/alarm")
    public void alarm(@RequestBody List<SwAlarmVO> alarmList){
        log.info("skywalking alarm message:{}",alarmList);
        //todo doalarm
    }
}
```
* 修改告警配置，开放webhook接口

* 为了模拟请求调用慢，我们在代码中使用`Thread.sleep(1000)`增加接口耗时，然后等webhoook接口告警响应
![image.png](https://img.hacpai.com/file/2019/11/image-08ec8aba.png)


详细信息如下：  
 ```
[SwAlarmVO(scopeId = 2, name = dubbo - consumer - pid: 13812 @ jianzhang11, id0 = 28, id1 = 0, 
alarmMessage = Response time of service instance dubbo - consumer - pid: 13812 @ jianzhang11 
is more than 1000ms in 2 minutes of last 10 minutes, startTime = 1573122018755), 
SwAlarmVO(scopeId = 2, name = dubbo - provider2 - pid: 14108 @ jianzhang11, id0 = 25,
 id1 = 0, alarmMessage = Response time of service instance dubbo - provider2 - pid: 14108 @ jianzhang11 
is more than 1000ms in 2 minutes of last 10 minutes, startTime = 1573122018755)]
 ```  
此时webhook能正常接收到sw的告警信息，后续的消息通知直接定制开发即可。
