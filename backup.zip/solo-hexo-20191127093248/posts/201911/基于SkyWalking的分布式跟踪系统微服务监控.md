title: 基于SkyWalking的分布式跟踪系统 - 微服务监控
date: '2019-11-26 08:49:24'
updated: '2019-11-26 08:49:24'
tags: [运维监控, Skywalking, 微服务]
permalink: /articles/2019/11/26/1574729364345.html
---
![](https://img.hacpai.com/bing/20190101.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

上一篇文章我们搭建了基于SkyWalking分布式跟踪环境，今天聊聊使用SkyWalking监控我们的微服务（DUBBO）

## 服务案例

假设你有个订单微服务，包含以下组件
* MySQL数据库分表分库（2台）
* 生产者（2台） dubbo-provider
* 消费者 dubbo-consumer

网络拓扑图如下
![image.png](https://img.hacpai.com/file/2019/11/image-a2927cf2.png)



生产者的关键代码
```
@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    protected OrderMapper orderMapper;

    @Override
    public OrderVO getById(long id) {
        OrderVO orderVO = new OrderVO();
        Order order = orderMapper.selectById(id);
        BeanUtils.copyProperties(order,orderVO);
        return orderVO;
    }
}
```

消费者的关键代码
```
@RestController
public class OrderController {

    @Reference(retries = 0)
    private OrderService orderService;

    @GetMapping("/order/{id}")
    public OrderVO getOrder(@PathVariable long id){
        return orderService.getById(id);
    }

}
```

## 监控启动

* 使用 `javaagent` 启动生产者

    `-javaagent:E:\讯飞开发工具\skywalking\agent\skywalking-agent.jar -Dskywalking.agent.service_name=dubbo-provider -Dskywalking.collector.backend_service=192.168.136.129:11800`

    `-javaagent:E:\讯飞开发工具\skywalking\agent\skywalking-agent.jar -Dskywalking.agent.service_name=dubbo-provider2 -Dskywalking.collector.backend_service=192.168.136.129:11800`

* 启动消费者  
`-javaagent:E:\讯飞开发工具\skywalking\agent\skywalking-agent.jar -Dskywalking.agent.service_name=dubbo-consumer -Dskywalking.collector.backend_service=192.168.136.129:11800`

* 模拟请求  
在浏览器访问`http://localhost:9090/order/1184489161562816511`，多次调用使负载生效；修改订单id参数，让调用覆盖不同的数据库

* 效果查看  
访问skywalking监控地址`http://192.168.136.129:8080/`查看监控效果
![image.png](https://img.hacpai.com/file/2019/11/image-c8836706.png)
仪表盘
![image.png](https://img.hacpai.com/file/2019/11/image-2d0df15b.png)
网络拓扑图
![image.png](https://img.hacpai.com/file/2019/11/image-a579b518.png)
错误日志
![image.png](https://img.hacpai.com/file/2019/11/image-a37b6932.png)
Trace查询


## 日志集成
这部分我们先看下调用链的原理：
* 请求到来生成一个全局TraceID，通过TraceID可以串联起整个调用链，一个TraceID代表一次请求。
* 除了TraceID外，还需要SpanID用于记录调用父子关系。每个服务会记录下Parent id和Span id，通过他们可以组织一次完整调用链的父子关系。
* 要查看某次完整的调用则只要根据TraceID查出所有调用记录，然后通过Parent id和Span id组织起整个调用父子关系。

正是由于TraceID如此重要，所以我们希望这个调用链的TraceID能输出在日志文件中，一旦观察到有异常调用，我们在日志分析平台直接搜索TraceID即可将关联的日志全部检索出来，大大提高我们解决问题的效率。

### 集成过程（log4j2）
* 引入日志包log4j2
    ```
    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter</artifactId>
        <exclusions>
            <exclusion>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-starter-logging</artifactId>
            </exclusion>
        </exclusions>
    </dependency>

    <dependency>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-log4j2</artifactId>
    </dependency>
    ```

* 引入SW工具包
    ```
     <!--SW trace 跟踪-->
    <dependency>
        <groupId>org.apache.skywalking</groupId>
        <artifactId>apm-toolkit-log4j-2.x</artifactId>
        <version>6.4.0</version>
    </dependency>
    ```

* 修改日志显示格式 log4j2.xml  
`%d [%traceId] %-5p %c{1}:%L - %m%n`

* 启动应用，观察控制台
![image.png](https://img.hacpai.com/file/2019/11/image-e534235b.png)
刚启动时候获取不到TraceID,所以TID显示为N/A，启动完成后调用请求再次观察控制台，发现所有链路上的日志都打上了TraceID。
![image.png](https://img.hacpai.com/file/2019/11/image-cea98a4a.png)


很简单的几步就让你的微服务加上了调用链监控，你还不赶紧试试？
