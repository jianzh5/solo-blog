title: 使用Prometheus监控SpringBoot应用
date: '2019-11-20 08:52:52'
updated: '2019-11-25 14:03:50'
tags: [Prometheus, 运维监控]
permalink: /articles/2019/11/20/1574211172794.html
---
![](https://img.hacpai.com/bing/20180223.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

通过之前的文章我们使用Prometheus监控了应用服务器node_exporter，数据库mysqld_exporter,今天我们来监控一下你的应用。（本文以SpringBoot 2.1.9.RELEASE 作为监控目标）


## 编码

### 添加依赖

使用Prometheus监控SpringBoot应用只需要在pom文件添加如下两个依赖：

```
<dependency>
	<groupId>org.springframework.boot</groupId>
	<artifactId>spring-boot-starter-actuator</artifactId>
</dependency>
<dependency>
	<groupId>io.micrometer</groupId>
	<artifactId>micrometer-registry-prometheus</artifactId>
</dependency>
```

### 修改配置

修改application.properties或者application.yml文件，对外暴露监控端点
```
spring.application.name = blog
management.endpoints.web.exposure.include = prometheus
management.metrics.tags.application = ${spring.application.name}
```


### 启动应用
访问`http://localhost:50378/actuator/`查看开放端点
![image.png](https://img.hacpai.com/file/2019/11/image-21056e41.png)


访问`http://localhost:50378/actuator/prometheus`查看Metrics
![image.png](https://img.hacpai.com/file/2019/11/image-1b580640.png)


之前的文章中都是监控一个实例，这次咱们把端口设置成随机，启动两个实例，等下看看监控效果。

## 监控配置

### Prometheus

修改prometheus.yml，增加监控任务
```
  - job_name: 'SpringBoot'
    metrics_path: '/actuator/prometheus'
    static_configs:
    - targets: ['10.1.61.10:50378','10.1.61.10:50822']
```
重启Prometheus，查看监控状态。
![image.png](https://img.hacpai.com/file/2019/11/image-4a8a0829.png)





### Grafana

直接从[grafana官网](https://grafana.com/grafana/dashboards)寻找JVM监控DashBoard，然后导入到Grafana中（在环境搭建篇中已经讲述了操作过程，这里就不再赘述）。
![image.png](https://img.hacpai.com/file/2019/11/image-cf431a86.png)


查看效果

![image.png](https://img.hacpai.com/file/2019/11/image-767eebcf.png)

![image.png](https://img.hacpai.com/file/2019/11/image-d8803a91.png)



## 彩蛋
我们关掉其中一个SpringBoot实例，等2分钟，然后邮箱会收到这样一封告警邮件
![image.png](https://img.hacpai.com/file/2019/11/image-d3a2fa4a.png)


**怎么实现的呢？咱们下期有缘再见！**



* * *
**相关文章**
* [基于Prometheus和Grafana的监控平台 - 环境搭建](https://mp.weixin.qq.com/s?__biz=Mzg3NjE0ODM2NA==&mid=2247483773&idx=1&sn=1e5ec2b59af5ac46661fcda19c6e31dc&chksm=cf37e29ef8406b886e30cf31d1024ca0fd25ae15e5248da92c4093f40213c7f3732e799bfa8f&mpshare=1&scene=1&srcid=1023OmwFQ8cnPgMCOXtWQXgn&sharer_sharetime=1571827301092&sharer_shareid=f4a0969410a6220c2924a1da2e3895da&key=f8a21a8df9909cbb9d1ab09f6201d9f35531596db156322af81d8cdf93130533bade86db2cb989aede1fb56d62d7cf07fad912ded6ccfae1b8ad505d77c4023c01a152f9d78bcd2cfb6ada6c829376af&ascene=1&uin=MTQ4ODgxOTEyOA%3D%3D&devicetype=Windows+10&version=62070152&lang=zh_CN&pass_ticket=sj27N%2Fx%2BTPwyy6DAsQ0GKmRD0BYbhN5dQDEh0Y7xN8ofkFU0UZHxwKxVv%2FHJ3hFO)

* [使用Prometheus监控MySQL性能指标](https://mp.weixin.qq.com/s?__biz=Mzg3NjE0ODM2NA==&mid=2247483777&idx=1&sn=c7bcc37b5cf628654bc4ba8d2e56798c&chksm=cf37e262f8406b74f5efd4555871e411cb18241f9a3e30f1aabeb5d7bd6eb6ae222a49b98006&mpshare=1&scene=1&srcid=1023vLxmNqELrfvZUww9I5bk&sharer_sharetime=1571827315466&sharer_shareid=f4a0969410a6220c2924a1da2e3895da&key=6f23511bf9e1c01fde8309d2b6d147bd50b60897702480bceed2072d94abd3504179c25ef83b2a9b2a8a65d2e02047f264ef07a18a2366edffa3a69a3d45b21727020deb7190483912bb59ca49e78402&ascene=1&uin=MTQ4ODgxOTEyOA%3D%3D&devicetype=Windows+10&version=62070152&lang=zh_CN&pass_ticket=sj27N%2Fx%2BTPwyy6DAsQ0GKmRD0BYbhN5dQDEh0Y7xN8ofkFU0UZHxwKxVv%2FHJ3hFO)
