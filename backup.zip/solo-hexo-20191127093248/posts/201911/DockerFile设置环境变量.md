title: DockerFile 设置环境变量
date: '2019-11-26 22:33:59'
updated: '2019-11-26 22:34:09'
tags: [Docker]
permalink: /articles/2019/11/26/1574778839208.html
---
![](https://img.hacpai.com/bing/20180903.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## 镜像的Layer

在docker docs里面有一句话：

> **We’ve already seen that Docker images are read-only templates from which Docker containers are launched. Each image consists of a series of layers. Docker makes use of union file systems to combine these layers into a single image. Union file systems allow files and directories of separate file systems, known as branches, to be transparently overlaid, forming a single coherent file system.**

对于docker的images，是由一层层的layer组成的，然后通过联合挂载的方式挂载成一个文件系统。

假设你有以下的dockerfile:

```css
FROM ubuntu
ENV http_proxy 10.144.xx.xx:8080
ENTRYPOINT ["/usr/bin/bash"]

```

首先你选择了基础镜像ubuntu，这个镜像有很多层。可以从/val/lib/docker下面找到该镜像的信息和每一层的信息。

然后ENV是设置了一个环境变量，这句命令同样会产生一个layer，再然后就是需要执行的命令，同样会产生一个layer。如果你更改了某一层的信息，那么从这层之后所有的层都需要重新build。

更多的关于docker images的原理，可以自行百度。

## DockerFile的ARG和ENV

ARG主要是定义一个变量，在你使用docker build的时候可以通过参数来设定。

```xml
docker build --build-arg <varname>=<value>

```

因此如果你需要在build期间使用某些变量，那么ARG是最好的选择。

如果你是想在运行期间使用，那么ENV是唯一的选择。

ENV主要是定义环境变量，在docker run的时候ENV的配置会加载到容易内部，但ARG的参数在内部是没法看到的。同时也可以通过下面命令更改ENV的默认值：

```csharp
docker run -e var=yyy

```

**<font color=red>如果现在我想在BUILD的时候，改变我的环境变量，而不是每次RUN的时候更改，需要怎么做？</font>**

这个时候就就可以两者结合使用。

```csharp
ARG var
ENV var=${var}

```

在dockerfile内部可以这样控制命令的参数。

```bash
ARG protocal
ARG address
ARG port

ENV protocal=${protocal} \
    address=${address} \
    port=${port}

CMD /usr/bin/lightweightservicediscovery --listen=${PROTOCAL:-ipv4}:${ADDRESS:-0.0.0.0}:${port:-49188}

//如果读取环境变量失败再采用后面的默认值。

```

这样既可以在build的时候通过docker build --build-arg var=xxx 来传递参数，也可以通过在运行的时候通过docker run -e var=yyy 来传递参数。

  
  
>作者：凹大猫的鱼  
>链接：https://www.jianshu.com/p/ae634ffb21ff
