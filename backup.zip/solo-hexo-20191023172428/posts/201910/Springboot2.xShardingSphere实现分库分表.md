title: Springboot2.x + ShardingSphere 实现分库分表
date: '2019-10-21 18:07:10'
updated: '2019-10-21 18:07:10'
tags: [SpringBoot, 分库分表, shardingsphere]
permalink: /articles/2019/10/21/1571652430697.html
---
![](https://img.hacpai.com/bing/20190817.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

之前一篇文章中我们讲了基于Mysql8的读写分离(文末有链接)，这次来说说分库分表的实现过程。

## 概念解析

### 垂直分片

按照业务拆分的方式称为垂直分片，又称为纵向拆分，它的核心理念是专库专用。 在拆分之前，一个数据库由多个数据表构成，每个表对应着不同的业务。而拆分之后，则是按照业务将表进行归类，分布到不同的数据库中，从而将压力分散至不同的数据库。 下图展示了根据业务需要，将用户表和订单表垂直分片到不同的数据库的方案。

![image.png](https://img.hacpai.com/file/2019/10/image-2c9fc6a4.png)

垂直分片往往需要对架构和设计进行调整。通常来讲，是来不及应对互联网业务需求快速变化的；而且，它也并无法真正的解决单点瓶颈。 垂直拆分可以缓解数据量和访问量带来的问题，但无法根治。如果垂直拆分之后，表中的数据量依然超过单节点所能承载的阈值，则需要水平分片来进一步处理。

### 水平分片

水平分片又称为横向拆分。 相对于垂直分片，它不再将数据根据业务逻辑分类，而是通过某个字段（或某几个字段），根据某种规则将数据分散至多个库或表中，每个分片仅包含数据的一部分。 例如：根据主键分片，偶数主键的记录放入0库（或表），奇数主键的记录放入1库（或表），如下图所示。

![image.png](https://img.hacpai.com/file/2019/10/image-d17e1d50.png)


水平分片从理论上突破了单机数据量处理的瓶颈，并且扩展相对自由，是分库分表的标准解决方案。

## 开发准备

分库分表常用的组件就是shardingsphere，目前已经是apache顶级项目，这次我们使用springboot2.1.9 + shardingsphere4.0.0-RC2（均为最新版本）来完成分库分表的操作。

假设有一张订单表，我们需要将它分成2个库，每个库三张表，根据id字段取模确定最终数据的位置，数据库环境配置如下：

* 172.31.0.129
    * blog
        * t_order_0
        * t_order_1
        * t_order_2
* 172.31.0.131
    * blog
        * t_order_0
        * t_order_1
        * t_order_2
 
三张表的逻辑表为t_order，大家可以根据建表语句准备好其他所有数据表。
```sql
DROP TABLE IF EXISTS `t_order_0;
CREATE TABLE `t_order_0` (
  `id` bigint(20) NOT NULL,
  `name` varchar(255) DEFAULT NULL COMMENT '名称',
  `type` varchar(255) DEFAULT NULL COMMENT '类型',
  `gmt_create` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
```
**注意，千万不能将主键的生成规则设置成自增长，需要按照一定规则来生成主键，这里使用shardingsphere中的SNOWFLAKE俗称雪花算法来生成主键**

## 代码实现

* 修改pom.xml,引入相关组件
```xml
<properties>
        <java.version>1.8</java.version>
        <mybatis-plus.version>3.1.1</mybatis-plus.version>
        <sharding-sphere.version>4.0.0-RC2</sharding-sphere.version>
    </properties>

    <dependencies>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>

        <dependency>
            <groupId>org.mybatis.spring.boot</groupId>
            <artifactId>mybatis-spring-boot-starter</artifactId>
            <version>2.0.1</version>
        </dependency>

        <dependency>
            <groupId>mysql</groupId>
            <artifactId>mysql-connector-java</artifactId>
            <version>8.0.15</version>
        </dependency>

        <dependency>
            <groupId>com.baomidou</groupId>
            <artifactId>mybatis-plus-boot-starter</artifactId>
            <version>${mybatis-plus.version}</version>
        </dependency>

        <dependency>
            <groupId>org.apache.shardingsphere</groupId>
            <artifactId>sharding-jdbc-spring-boot-starter</artifactId>
            <version>${sharding-sphere.version}</version>
        </dependency>

        <dependency>
            <groupId>org.apache.shardingsphere</groupId>
            <artifactId>sharding-jdbc-spring-namespace</artifactId>
            <version>${sharding-sphere.version}</version>
        </dependency>

        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
            <optional>true</optional>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
        </dependency>
    </dependencies>

    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
            </plugin>
        </plugins>
    </build>
```  


* 配置mysql-plus  

```
@Configuration
@MapperScan("com.github.jianzh5.blog.mapper")
public class MybatisPlusConfig {
	/**
	 * 攻击 SQL 阻断解析器
	 */
	@Bean
	public PaginationInterceptor paginationInterceptor(){
		PaginationInterceptor paginationInterceptor = new PaginationInterceptor();
		List<ISqlParser> sqlParserList = new ArrayList<>();
		sqlParserList.add(new BlockAttackSqlParser());

		paginationInterceptor.setSqlParserList(sqlParserList);
		return new PaginationInterceptor();
	}


	/**
	 * SQL执行效率插件
	 */
	@Bean
	// @Profile({"dev","test"})
	public PerformanceInterceptor performanceInterceptor() {
		return new PerformanceInterceptor();
	}
}
```

* 编写实体类Order

```
@Data
@TableName("t_order")
public class Order {
	private Long id;
	private String name;
	private String type;
	private Date gmtCreate;
}
```

* 编写DAO层,OrderMapper

```java
/**
 * 订单Dao层
 */
public interface OrderMapper extends BaseMapper<Order> {

}
```


* 编写接口及接口实现

```java
public interface OrderService extends IService<Order> {

}

/**
 * 订单实现层
 * @author jianzh5
 * @date 2019/10/15 17:05
 */
@Service
public class OrderServiceImpl extends ServiceImpl<OrderMapper, Order> implements OrderService {

}
```

* 配置文件（配置说明见备注）

```
server.port=8080

# 配置ds0 和ds1两个数据源
spring.shardingsphere.datasource.names = ds0,ds1

#ds0 配置
spring.shardingsphere.datasource.ds0.type = com.zaxxer.hikari.HikariDataSource
spring.shardingsphere.datasource.ds0.driver-class-name = com.mysql.cj.jdbc.Driver
spring.shardingsphere.datasource.ds0.jdbc-url = jdbc:mysql://192.168.249.129:3306/blog?characterEncoding=utf8&zeroDateTimeBehavior=convertToNull&useSSL=false
spring.shardingsphere.datasource.ds0.username = root
spring.shardingsphere.datasource.ds0.password = 000000

#ds1 配置
spring.shardingsphere.datasource.ds1.type = com.zaxxer.hikari.HikariDataSource
spring.shardingsphere.datasource.ds1.driver-class-name = com.mysql.cj.jdbc.Driver
spring.shardingsphere.datasource.ds1.jdbc-url = jdbc:mysql://192.168.249.131:3306/blog?characterEncoding=utf8&zeroDateTimeBehavior=convertToNull&useSSL=false
spring.shardingsphere.datasource.ds1.username = root
spring.shardingsphere.datasource.ds1.password = 000000

# 分库策略 根据id取模确定数据进哪个数据库
spring.shardingsphere.sharding.default-database-strategy.inline.sharding-column = id
spring.shardingsphere.sharding.default-database-strategy.inline.algorithm-expression = ds$->{id % 2}

# 具体分表策略
# 节点 ds0.t_order_0,ds0.t_order_1,ds1.t_order_0,ds1.t_order_1
spring.shardingsphere.sharding.tables.t_order.actual-data-nodes = ds$->{0..1}.t_order_$->{0..2}
# 分表字段id
spring.shardingsphere.sharding.tables.t_order.table-strategy.inline.sharding-column = id
# 分表策略 根据id取模,确定数据最终落在那个表中
spring.shardingsphere.sharding.tables.t_order.table-strategy.inline.algorithm-expression = t_order_$->{id % 3}


# 使用SNOWFLAKE算法生成主键
spring.shardingsphere.sharding.tables.t_order.key-generator.column = id
spring.shardingsphere.sharding.tables.t_order.key-generator.type = SNOWFLAKE

#spring.shardingsphere.sharding.binding-tables=t_order

spring.shardingsphere.props.sql.show = true
```

* 编写单元测试，查看结果是否正确

```java
public class OrderServiceImplTest extends BlogApplicationTests {
	@Autowired
	private OrderService orderService;

	@Test
	public void testSave(){
		for (int i = 0 ; i< 100 ; i++){
			Order order = new Order();
			order.setName("电脑"+i);
			order.setType("办公");
			orderService.save(order);
		}
	}

	@Test
	public void testGetById(){
		long id = 1184489163202789377L;
		Order order  = orderService.getById(id);
		System.out.println(order.toString());
	}
}
```

* 在数据表中查看数据，确认数据正常插入
![image.png](https://img.hacpai.com/file/2019/10/image-54f73377.png)


* 至此分库分表开发完成



**往期回顾**
>  [SpringBoot+Mysql8实现读写分离](
https://mp.weixin.qq.com/s?__biz=Mzg3NjE0ODM2NA==&mid=2247483762&idx=1&sn=330793a96c6ec09a05d41fec23c20d24&chksm=cf37e291f8406b87e893714573b670f7b3d11f0b650b88f2b8507cff7b263162af05aa98e115&scene=0&xtrack=1&key=2a4ff15fdd8463466a8a40f50f7a26d494172ee4c2f08a0e6b200e2a3b269af6c1edd17ef923adb9b39896c1d9653fcdf4d7601db5fff24ae4542b99baeed7aad4355bedcf0087a42791d3c2d21660ec&ascene=1&uin=MTQ4ODgxOTEyOA%3D%3D&devicetype=Windows+10&version=62070141&lang=zh_CN&pass_ticket=XIjojDGcywX0Q%2BkYQyTCcThNvN6IBG2diTO64EKVIwJ0STB%2ByfnOGvGfjJgRsIy4)





