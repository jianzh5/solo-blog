title: 腾讯Techo开发者大会PPT分享
date: '2019-11-20 16:26:51'
updated: '2019-11-20 16:51:42'
tags: [程序员必读书籍]
permalink: /articles/2019/11/20/1574238411928.html
---
![](https://img.hacpai.com/bing/20181011.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

腾讯云年度的开发者大会已经落幕，大会包括1场前沿技术主峰会，18个技术专场，150位海内外技术专家，28个互动展区，8场动手实验室，23小时小程序云开发极限编程，1场数据库诊断大赛。

内容上涵盖了最新云计算发展趋势，来自谷歌、Netflix、腾讯等技术先锋分享的云上基础设施演进、云原生、机器学习、音视频等；同时，腾讯在大会现场发布了四大开源联合项目：分布式消息中间件TubeMQ、Tencent Kona JDK、分布式HTAP数据库TBase、企业级容器平台TKEStac。

### 大会简介：  
![image.png](https://img.hacpai.com/file/2019/11/image-51d01550.png)


### 大会嘉宾
![image.png](https://img.hacpai.com/file/2019/11/image-81da67f9.png)
![image.png](https://img.hacpai.com/file/2019/11/image-f961b534.png)
![image.png](https://img.hacpai.com/file/2019/11/image-7899b259.png)
![image.png](https://img.hacpai.com/file/2019/11/image-7d036eab.png)

  
有没有你认识的呢？

### 大会内容
![image.png](https://img.hacpai.com/file/2019/11/image-a9bdb696.png)
![image.png](https://img.hacpai.com/file/2019/11/image-bde941a9.png)
![image.png](https://img.hacpai.com/file/2019/11/image-fbba6c70.png)
![image.png](https://img.hacpai.com/file/2019/11/image-43b07595.png)



> **本次大会独家的109份干货PPT，关注公众号:JAVA日知录,回复关键字techo即可领取**
